jQuery(document).ready(function($) {
	"use strict";
	$('.slzcore-meta-color').wpColorPicker();
});