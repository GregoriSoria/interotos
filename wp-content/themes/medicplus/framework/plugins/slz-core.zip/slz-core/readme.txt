== SlzCore ==
Contributors: swlabs
Tags: custom post type, shortcode, metabox.

SlzCore plugin compatible with MedicPlus Wordpress template.

Thanks for your support and feel free to contact us any time. 
Our support forum is here:

http://support.swlabs.co/